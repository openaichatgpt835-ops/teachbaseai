"""Bitrix OAuth, install, handler, events."""
import json
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

from fastapi import APIRouter, Request, Depends
from fastapi.responses import RedirectResponse, JSONResponse, HTMLResponse, PlainTextResponse

from pydantic import BaseModel

from sqlalchemy.orm import Session
from sqlalchemy import select, delete

from apps.backend.deps import get_db
from apps.backend.config import get_settings
from apps.backend.models.portal import Portal, PortalUsersAccess
from apps.backend.auth import create_portal_token, require_portal_access
from apps.backend.clients.bitrix import exchange_code, user_get
from apps.backend.services.bitrix_events import process_imbot_message
from apps.backend.services.portal_tokens import save_tokens, get_access_token
from apps.backend.services.token_crypto import encrypt_token
from apps.backend.services.finalize_install import finalize_install, step_provision_chats
from apps.backend.services.bot_provisioning import ensure_bot_registered
from apps.backend.clients.bitrix import imbot_bot_list, BOT_CODE_DEFAULT
from apps.backend.utils.bitrix_request import parse_bitrix_body

router = APIRouter()

_install_html: str | None = None
_handler_html: str | None = None
_app_html: str | None = None


def _html_ui_response(html: str) -> HTMLResponse:
    resp = HTMLResponse(html)
    resp.headers["Content-Type"] = "text/html; charset=utf-8"
    resp.headers["X-Teachbase-UI"] = "1"
    return resp


def _load_install_html() -> str:
    global _install_html
    if _install_html is None:
        p = Path(__file__).resolve().parent.parent / "templates" / "install.html"
        _install_html = p.read_text(encoding="utf-8")
    return _install_html


def _load_handler_html() -> str:
    global _handler_html
    if _handler_html is None:
        p = Path(__file__).resolve().parent.parent / "templates" / "handler.html"
        _handler_html = p.read_text(encoding="utf-8")
    return _handler_html


def _load_app_html() -> str:
    global _app_html
    if _app_html is None:
        p = Path(__file__).resolve().parent.parent / "templates" / "app.html"
        _app_html = p.read_text(encoding="utf-8")
    return _app_html


def _domain_clean(domain: str) -> str:
    return domain.replace("https://", "").replace("http://", "").rstrip("/").split("/")[0]


def _trace_id(request: Request) -> str:
    return getattr(request.state, "trace_id", "") or ""


def _is_document_navigation(request: Request) -> bool:
    h = request.headers
    dest = (h.get("Sec-Fetch-Dest") or "").strip().lower()
    if dest in ("document", "iframe", "embed"):
        return True
    mode = (h.get("Sec-Fetch-Mode") or "").strip().lower()
    if mode == "navigate":
        return True
    accept = (h.get("Accept") or "").lower()
    if "text/html" in accept or "application/xhtml+xml" in accept:
        return True
    return False


def _is_json_api_request(request: Request) -> bool:
    h = request.headers
    if _is_document_navigation(request):
        return False
    if h.get("X-Requested-With") == "XMLHttpRequest":
        return True
    accept = (h.get("Accept") or "").lower()
    mode = (h.get("Sec-Fetch-Mode") or "").strip().lower()
    if "application/json" in accept and mode in ("cors", "same-origin", "no-cors"):
        return True
    return False


def _log_bitrix_install_xhr(
    trace_id: str,
    portal_id: int | None,
    step: str,
    path: str,
    http_status: int,
    bitrix_method: str | None = None,
    err_code: str | None = None,
    safe_err: str | None = None,
) -> None:
    """Structured log for install XHR. No domain, no tokens."""
    log_obj = {
        "type": "bitrix_install_xhr",
        "trace_id": trace_id,
        "portal_id": portal_id,
        "step": step,
        "path": path,
        "http_status": http_status,
    }
    if bitrix_method:
        log_obj["bitrix_method"] = bitrix_method
    if err_code:
        log_obj["err_code"] = err_code
    if safe_err:
        log_obj["safe_err"] = safe_err[:200]
    logger.info("bitrix_install_xhr %s", json.dumps(log_obj, ensure_ascii=False))


def _parse_install_auth(merged: dict) -> tuple[str | None, str | None, str | None, str, str | None, str | None, str | None]:
    auth = merged.get("auth", merged)
    if isinstance(auth, str):
        try:
            auth = json.loads(auth) if auth else {}
        except Exception:
            auth = {}
    if not isinstance(auth, dict):
        auth = {}
    access_token = (
        merged.get("AUTH_ID")
        or auth.get("access_token")
        or auth.get("ACCESS_TOKEN")
    )
    refresh_token = (
        merged.get("REFRESH_ID")
        or auth.get("refresh_token")
        or auth.get("REFRESH_TOKEN")
    )
    domain = merged.get("DOMAIN") or auth.get("domain") or auth.get("DOMAIN")
    member_id = str(merged.get("MEMBER_ID") or auth.get("member_id") or auth.get("MEMBER_ID") or "")
    app_sid = merged.get("APP_SID") or auth.get("application_token") or auth.get("APP_SID")
    local_client_id = merged.get("local_client_id") or auth.get("local_client_id")
    local_client_secret = merged.get("local_client_secret") or auth.get("local_client_secret")
    return access_token, refresh_token, domain, member_id, app_sid, local_client_id, local_client_secret


@router.get("/oauth/callback")
def oauth_callback(
    code: str | None = None,
    domain: str | None = None,
    db: Session = Depends(get_db),
):
    s = get_settings()
    if not code or not domain:
        return JSONResponse({"error": "Missing code or domain"}, status_code=400)
    if not s.public_base_url:
        return JSONResponse({"error": "PUBLIC_BASE_URL не настроен"}, status_code=500)
    cid = s.bitrix_app_client_id or s.bitrix_client_id
    csec = s.bitrix_app_client_secret or s.bitrix_client_secret
    if not cid or not csec:
        return JSONResponse({"error": "Bitrix app не настроен"}, status_code=500)
    redirect_uri = f"{s.public_base_url.rstrip('/')}/api/v1/bitrix/oauth/callback"
    result = exchange_code(
        domain, code,
        cid, csec,
        redirect_uri,
    )
    if not result:
        return JSONResponse({"error": "OAuth exchange failed"}, status_code=400)
    domain_clean = _domain_clean(domain)
    portal = db.execute(select(Portal).where(Portal.domain == domain_clean)).scalar_one_or_none()
    if not portal:
        portal = Portal(domain=domain_clean, status="active")
        db.add(portal)
        db.commit()
        db.refresh(portal)
    save_tokens(
        db, portal.id,
        result.get("access_token", ""),
        result.get("refresh_token", ""),
        int(result.get("expires_in", 3600)),
    )
    return RedirectResponse(url=f"https://{domain_clean}/marketplace/app/", status_code=302)


@router.get("/install")
async def bitrix_install_get():
    """UI-страница установки: загружает BX24 SDK, получает auth через BX24, POST на complete."""
    return _html_ui_response(_load_install_html())


@router.get("/test-iframe")
async def bitrix_test_iframe():
    """Тестовая страница: показывает iframe с /install, чтобы увидеть реальное поведение."""
    html = """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Test iframe</title>
  <style>
    body { font-family: system-ui; padding: 1rem; }
    iframe { width: 100%; height: 600px; border: 2px solid #333; }
    pre { background: #f5f5f5; padding: 1rem; overflow: auto; max-height: 200px; }
  </style>
</head>
<body>
  <h1>Тест iframe /install</h1>
  <p>Ниже iframe с src="/api/v1/bitrix/install". Смотрим что там рендерится.</p>
  <iframe id="frame" src="/api/v1/bitrix/install"></iframe>
  <h2>Логи (fetch перехват)</h2>
  <pre id="log">Загрузка...</pre>
</body>
</html>"""
    return HTMLResponse(html)


def _is_install_complete_api_request(request: Request) -> bool:
    """True только если запрос — явный fetch/XHR из install.html с X-Requested-With."""
    # ЖЕЛЕЗОБЕТОННАЯ ЗАЩИТА: JSON только для XHR/fetch, document/iframe всегда редирект.
    return _is_json_api_request(request)


def _install_redirect_url(request: Request) -> str:
    s = get_settings()
    base = (s.public_base_url or "").rstrip("/")
    if base and base.startswith("http"):
        return base + "/api/v1/bitrix/install"
    return str(request.base_url).rstrip("/") + "/api/v1/bitrix/install"


def _handler_redirect_url(request: Request) -> str:
    s = get_settings()
    base = (s.public_base_url or "").rstrip("/")
    if base and base.startswith("http"):
        return base + "/api/v1/bitrix/handler"
    return str(request.base_url).rstrip("/") + "/api/v1/bitrix/handler"


def _app_redirect_url(request: Request) -> str:
    s = get_settings()
    base = (s.public_base_url or "").rstrip("/")
    if base and base.startswith("http"):
        return base + "/api/v1/bitrix/install"
    return str(request.base_url).rstrip("/") + "/api/v1/bitrix/install"


@router.get("/app")
async def bitrix_app_get(request: Request):
    """HTML страница «Статус». Document/iframe — всегда 200 HTML. Без интеграции клиент редиректит на install."""
    if _is_json_api_request(request):
        return RedirectResponse(url=_app_redirect_url(request), status_code=303)
    return _html_ui_response(_load_app_html())


class AppStatusBody(BaseModel):
    auth: dict = {}


@router.post("/app/status")
async def bitrix_app_status(request: Request, body: AppStatusBody, db: Session = Depends(get_db)):
    """JSON: статус портала по auth (domain + access_token). XHR only."""
    if not _is_json_api_request(request):
        return RedirectResponse(url=_app_redirect_url(request), status_code=303)
    auth = body.auth or {}
    domain = (auth.get("domain") or auth.get("DOMAIN") or "").strip()
    if not domain:
        return JSONResponse({"installed": False, "error": "missing_domain"}, status_code=400)
    domain_clean = _domain_clean(domain)
    portal = db.execute(select(Portal).where(Portal.domain == domain_clean)).scalar_one_or_none()
    if not portal:
        return JSONResponse({"installed": False}, status_code=404)
    meta = {}
    if portal.metadata_json:
        try:
            meta = json.loads(portal.metadata_json) if isinstance(portal.metadata_json, str) else portal.metadata_json
        except Exception:
            pass
    bot_id = meta.get("bot_id")
    bot_status = "registered" if bot_id else "not_registered"
    rows = db.execute(
        select(PortalUsersAccess).where(PortalUsersAccess.portal_id == portal.id)
    ).scalars().all()
    allowlist = [{"user_id": r.user_id, "name": None} for r in rows]
    from datetime import datetime, timedelta
    from apps.backend.models.event import Event
    since = datetime.utcnow() - timedelta(hours=24)
    events_24h = db.execute(
        select(Event).where(Event.portal_id == portal.id, Event.created_at >= since)
    ).scalars().all()
    in_24h = sum(1 for e in events_24h if e.event_type == "rx")
    blocked_24h = sum(1 for e in events_24h if e.event_type == "blocked_by_acl")
    out_24h = sum(1 for e in events_24h if e.event_type and "tx" in str(e.event_type))
    return JSONResponse({
        "installed": True,
        "domain": portal.domain,
        "bot_status": bot_status,
        "bot_id": bot_id,
        "bot_code": BOT_CODE_DEFAULT,
        "allowlist": allowlist,
        "stats": {"in_24h": in_24h, "out_24h": out_24h, "blocked_24h": blocked_24h},
    })


@router.post("/app/provision")
async def bitrix_app_provision(request: Request, body: AppStatusBody, db: Session = Depends(get_db)):
    """Запуск provision по allowlist. XHR only, auth в body."""
    if not _is_json_api_request(request):
        return RedirectResponse(url=_app_redirect_url(request), status_code=303)
    auth = body.auth or {}
    domain = (auth.get("domain") or auth.get("DOMAIN") or "").strip()
    access_token = auth.get("access_token") or auth.get("ACCESS_TOKEN") or auth.get("AUTH_ID")
    if not domain or not access_token:
        return JSONResponse({"error": "missing_auth"}, status_code=400)
    domain_clean = _domain_clean(domain)
    portal = db.execute(select(Portal).where(Portal.domain == domain_clean)).scalar_one_or_none()
    if not portal:
        return JSONResponse({"error": "portal_not_found"}, status_code=404)
    domain_full = f"https://{domain_clean}" if not domain_clean.startswith("http") else domain_clean
    bot_result = ensure_bot_registered(db, portal.id, _trace_id(request), domain=domain_full, access_token=access_token)
    if not bot_result.get("ok"):
        return JSONResponse({"error": bot_result.get("error_code", "bot_not_registered")}, status_code=400)
    bot_id = bot_result.get("bot_id") or 0
    if not bot_id:
        return JSONResponse({"error": "bot_id_missing"}, status_code=400)
    allowlist_rows = db.execute(
        select(PortalUsersAccess.user_id).where(PortalUsersAccess.portal_id == portal.id)
    ).scalars().all()
    user_ids = []
    for (uid,) in allowlist_rows:
        try:
            user_ids.append(int(uid))
        except (TypeError, ValueError):
            pass
    if not user_ids:
        return JSONResponse({"status": "ok", "ok_count": 0, "failed_count": 0, "trace_id": _trace_id(request)})
    trace_id = _trace_id(request)
    welcome_msg = (getattr(portal, "welcome_message", None) or "").strip() or "Привет! Я Teachbase AI. Напишите «ping» — отвечу «pong»."
    res = step_provision_chats(db, portal.id, domain_full, access_token, bot_id, user_ids, trace_id, welcome_message=welcome_msg)
    return JSONResponse({
        "status": res.get("status"),
        "ok_count": res.get("ok", 0),
        "failed_count": len(res.get("failed", [])),
        "trace_id": trace_id,
        "failed": res.get("failed", []),
    })


@router.post("/app/bot-check")
async def bitrix_app_bot_check(request: Request, body: AppStatusBody, db: Session = Depends(get_db)):
    """Проверка бота imbot.bot.list. XHR only. Возвращает bots_count, sample_bots, found_by, bot_status."""
    if not _is_json_api_request(request):
        return RedirectResponse(url=_app_redirect_url(request), status_code=303)
    auth = body.auth or {}
    domain = (auth.get("domain") or auth.get("DOMAIN") or "").strip()
    access_token = auth.get("access_token") or auth.get("ACCESS_TOKEN") or auth.get("AUTH_ID")
    if not domain or not access_token:
        return JSONResponse({"error": "missing_auth", "bots_count": 0}, status_code=400)
    domain_clean = _domain_clean(domain)
    portal = db.execute(select(Portal).where(Portal.domain == domain_clean)).scalar_one_or_none()
    if not portal:
        return JSONResponse({"error": "portal_not_found", "bots_count": 0}, status_code=404)
    domain_full = f"https://{domain_clean}" if not domain_clean.startswith("http") else domain_clean
    bots, err = imbot_bot_list(domain_full, access_token)
    meta = {}
    if portal.metadata_json:
        try:
            meta = json.loads(portal.metadata_json) if isinstance(portal.metadata_json, str) else portal.metadata_json
        except Exception:
            pass
    our_bot_id = meta.get("bot_id")
    found_by = None
    if our_bot_id and bots:
        for b in bots:
            bid = b.get("id") or b.get("ID")
            if bid is not None and int(bid) == int(our_bot_id):
                found_by = "id"
                break
    if not found_by and bots:
        for b in bots:
            if (b.get("code") or b.get("CODE") or "").strip() == BOT_CODE_DEFAULT:
                found_by = "code"
                break
    bot_found = bool(found_by)
    bot_status = "verified" if bot_found else ("registered_unverified" if our_bot_id else "not_registered")
    sample = (bots[:5] if bots else [])
    sample_bots = [{"id": b.get("id") or b.get("ID"), "code": (b.get("code") or b.get("CODE") or "")[:32]} for b in sample]
    return JSONResponse({
        "bots_count": len(bots),
        "sample_bots": sample_bots,
        "found_by": found_by,
        "bot_found_in_bitrix": bot_found,
        "bot_status": bot_status,
    })


@router.get("/install/complete")
async def bitrix_install_complete_get(request: Request):
    """GET /install/complete не поддерживается как документ — редирект на страницу установки."""
    logger.info("install_complete_mode=document_blocked trace_id=%s method=GET", _trace_id(request))
    return RedirectResponse(url=_install_redirect_url(request), status_code=303)


@router.post("/install/complete")
async def bitrix_install_complete(request: Request, db: Session = Depends(get_db)):
    """API only: вызывайте через fetch из install.html. При document navigation — 303 на /install."""
    tid = _trace_id(request)
    if not _is_install_complete_api_request(request):
        logger.info("install_complete_mode=document_blocked trace_id=%s method=POST", tid)
        redirect_url = _install_redirect_url(request)
        return RedirectResponse(url=redirect_url, status_code=303)
    logger.info("install_complete_mode=api trace_id=%s", tid)
    merged = await parse_bitrix_body(request)
    (
        access_token,
        refresh_token,
        domain,
        member_id,
        app_sid,
        local_client_id,
        local_client_secret,
    ) = _parse_install_auth(merged)
    if not domain:
        return JSONResponse(
            {"error": "Missing domain", "status": "error", "trace_id": tid},
            status_code=400,
        )
    if not access_token:
        return JSONResponse(
            {"error": "Missing access_token", "status": "error", "trace_id": tid},
            status_code=400,
        )
    domain_clean = _domain_clean(domain)
    portal = db.execute(select(Portal).where(Portal.domain == domain_clean)).scalar_one_or_none()
    s = get_settings()
    enc_key = s.token_encryption_key or s.secret_key
    if not portal:
        portal = Portal(domain=domain_clean, member_id=member_id, status="active")
        if local_client_id:
            portal.local_client_id = str(local_client_id)
        if local_client_secret and enc_key:
            portal.local_client_secret_encrypted = encrypt_token(str(local_client_secret), enc_key)
        db.add(portal)
        db.commit()
        db.refresh(portal)
    else:
        portal.member_id = member_id
        if local_client_id:
            portal.local_client_id = str(local_client_id)
        if local_client_secret and enc_key:
            portal.local_client_secret_encrypted = encrypt_token(str(local_client_secret), enc_key)
        db.commit()
    save_tokens(db, portal.id, access_token, refresh_token or "", 3600)
    domain_full = f"https://{domain_clean}"
    bot_result = ensure_bot_registered(
        db, portal.id, tid,
        domain=domain_full,
        access_token=access_token,
    )
    bot_status = "ok" if bot_result.get("ok") else "error"
    bot_payload = {
        "status": bot_status,
        "bot_id_present": bool(bot_result.get("bot_id")),
        "error_code": bot_result.get("error_code"),
        "error_detail_safe": bot_result.get("error_detail_safe"),
    }
    _log_bitrix_install_xhr(tid, portal.id, "complete", request.url.path, 200)
    portal_token = create_portal_token(portal.id, expires_minutes=15)
    resp = JSONResponse({
        "status": "ok",
        "trace_id": tid,
        "portal_id": portal.id,
        "portal_token": portal_token,
        "bot": bot_payload,
    })
    resp.headers["X-Trace-Id"] = tid
    return resp


@router.post("/session/start")
async def bitrix_session_start(request: Request, db: Session = Depends(get_db)):
    """Выдаёт portal_token по domain/member_id + access_token (для iframe)."""
    if not _is_json_api_request(request):
        redirect_url = _handler_redirect_url(request)
        return RedirectResponse(url=redirect_url, status_code=303)
    merged = await parse_bitrix_body(request)
    tid = _trace_id(request)
    auth = merged.get("auth", merged)
    if isinstance(auth, str):
        try:
            auth = json.loads(auth) if auth else {}
        except Exception:
            auth = {}
    domain = (merged.get("DOMAIN") or auth.get("domain") or auth.get("DOMAIN") or "").strip()
    member_id = str(merged.get("MEMBER_ID") or auth.get("member_id") or auth.get("MEMBER_ID") or "")
    access_token = merged.get("AUTH_ID") or auth.get("access_token") or auth.get("ACCESS_TOKEN")
    if not domain or not access_token:
        return JSONResponse(
            {"error": "Missing domain or access_token", "trace_id": tid},
            status_code=400,
        )
    domain_clean = _domain_clean(domain)
    portal = db.execute(select(Portal).where(Portal.domain == domain_clean)).scalar_one_or_none()
    if not portal:
        return JSONResponse(
            {"error": "Portal not found", "trace_id": tid},
            status_code=404,
        )
    portal_token = create_portal_token(portal.id, expires_minutes=15)
    return JSONResponse({"portal_token": portal_token, "portal_id": portal.id})


@router.get("/users")
async def bitrix_users(
    request: Request,
    portal_id: int,
    start: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    pid: int = Depends(require_portal_access),
):
    """Список сотрудников портала (user.get). Требует scope user."""
    if pid != portal_id:
        return JSONResponse({"error": "Forbidden", "detail": "portal_id mismatch"}, status_code=403)
    portal = db.execute(select(Portal).where(Portal.id == portal_id)).scalar_one_or_none()
    if not portal:
        return JSONResponse({"error": "Portal not found"}, status_code=404)
    access_token = get_access_token(db, portal_id)
    if not access_token:
        return JSONResponse({"error": "No token for portal"}, status_code=400)
    domain_full = f"https://{portal.domain}"
    users_list, err = user_get(domain_full, access_token, start=start, limit=limit)
    if err == "missing_scope_user":
        return JSONResponse(
            {"error": "missing_scope_user", "detail": "Не хватает права user. Добавьте право user в приложении Bitrix24 и переустановите."},
            status_code=403,
        )
    if err:
        return JSONResponse({"error": err}, status_code=502)
    out = [
        {
            "id": u.get("ID"),
            "name": u.get("NAME") or "",
            "last_name": u.get("LAST_NAME") or "",
            "email": u.get("EMAIL") or "",
            "active": u.get("ACTIVE") is True,
        }
        for u in users_list
    ]
    return JSONResponse({"users": out, "total": len(out)})


class AccessUsersBody(BaseModel):
    user_ids: list[int]


class FinalizeInstallBody(BaseModel):
    portal_id: int
    selected_user_ids: list[int]
    auth_context: dict = {}


@router.get("/portals/{portal_id}/access/users")
async def get_portal_access_users(
    portal_id: int,
    db: Session = Depends(get_db),
    pid: int = Depends(require_portal_access),
):
    """Список разрешённых user_id портала."""
    if pid != portal_id:
        return JSONResponse({"error": "Forbidden"}, status_code=403)
    rows = db.execute(
        select(PortalUsersAccess).where(PortalUsersAccess.portal_id == portal_id)
    ).scalars().all()
    return JSONResponse({"user_ids": [r.user_id for r in rows]})


@router.put("/portals/{portal_id}/access/users")
async def put_portal_access_users(
    portal_id: int,
    body: AccessUsersBody,
    db: Session = Depends(get_db),
    pid: int = Depends(require_portal_access),
):
    """Bulk replace allowlist. user_ids — список Bitrix user ID."""
    if pid != portal_id:
        return JSONResponse({"error": "Forbidden"}, status_code=403)
    user_ids_str = [str(uid) for uid in body.user_ids]
    db.execute(delete(PortalUsersAccess).where(PortalUsersAccess.portal_id == portal_id))
    for uid in user_ids_str:
        db.add(PortalUsersAccess(portal_id=portal_id, user_id=uid))
    db.commit()
    return JSONResponse({"status": "ok", "count": len(user_ids_str)})


@router.post("/install")
async def bitrix_install_post(request: Request, db: Session = Depends(get_db)):
    """Fallback: Bitrix POST с AUTH_ID в query/form. Если нет токена — отдаём HTML UI."""
    if not _is_json_api_request(request):
        return _html_ui_response(_load_install_html())
    merged = await parse_bitrix_body(request)
    tid = _trace_id(request)
    (
        access_token,
        refresh_token,
        domain,
        member_id,
        app_sid,
        local_client_id,
        local_client_secret,
    ) = _parse_install_auth(merged)
    if not domain:
        return JSONResponse(
            {"error": "Missing domain", "status": "error", "trace_id": tid},
            status_code=400,
        )
    if not access_token:
        return _html_ui_response(_load_install_html())
    domain_clean = _domain_clean(domain)
    s = get_settings()
    enc_key = s.token_encryption_key or s.secret_key
    portal = db.execute(select(Portal).where(Portal.domain == domain_clean)).scalar_one_or_none()
    if not portal:
        portal = Portal(domain=domain_clean, member_id=str(member_id), status="active")
        if local_client_id:
            portal.local_client_id = str(local_client_id)
        if local_client_secret and enc_key:
            portal.local_client_secret_encrypted = encrypt_token(str(local_client_secret), enc_key)
        db.add(portal)
        db.commit()
        db.refresh(portal)
    else:
        portal.member_id = str(member_id)
        if local_client_id:
            portal.local_client_id = str(local_client_id)
        if local_client_secret and enc_key:
            portal.local_client_secret_encrypted = encrypt_token(str(local_client_secret), enc_key)
        db.commit()
    save_tokens(db, portal.id, access_token, refresh_token or "", 3600)
    portal_token = create_portal_token(portal.id, expires_minutes=15)
    return JSONResponse({"status": "ok", "portal_id": portal.id, "portal_token": portal_token})


@router.post("/install/finalize")
async def bitrix_install_finalize(
    request: Request,
    body: FinalizeInstallBody,
    db: Session = Depends(get_db),
    pid: int = Depends(require_portal_access),
):
    """Finalize install: allowlist -> ensure bot -> provision chats. XHR only."""
    if not _is_json_api_request(request):
        return RedirectResponse(url=_install_redirect_url(request), status_code=303)
    if pid != body.portal_id:
        return JSONResponse({"error": "Forbidden"}, status_code=403)
    trace_id = _trace_id(request)
    try:
        result = finalize_install(
            db,
            portal_id=body.portal_id,
            selected_user_ids=body.selected_user_ids,
            auth_context=body.auth_context or {},
            trace_id=trace_id,
        )
        status_code = 200
        _log_bitrix_install_xhr(
            trace_id, body.portal_id, "finalize", request.url.path, status_code,
        )
        resp = JSONResponse(result)
        resp.headers["X-Trace-Id"] = trace_id
        return resp
    except Exception as e:
        safe_err = str(e)[:200].replace("'", "")
        _log_bitrix_install_xhr(
            trace_id, body.portal_id, "finalize", request.url.path, 500,
            err_code="internal_error", safe_err=safe_err,
        )
        resp = JSONResponse(
            {"error": "internal_error", "trace_id": trace_id},
            status_code=500,
        )
        resp.headers["X-Trace-Id"] = trace_id
        return resp


@router.api_route("/handler", methods=["GET", "POST"])
async def bitrix_handler(request: Request, db: Session = Depends(get_db)):
    """Обработчик: placement (GET) — HTML UI с управлением доступом, события (POST) — JSON."""
    if request.method == "GET":
        return _html_ui_response(_load_handler_html())
    merged = await parse_bitrix_body(request)
    tid = _trace_id(request)
    event = merged.get("event", "")
    data = merged.get("data", merged)
    auth = merged.get("auth", {})
    if isinstance(auth, str):
        try:
            auth = json.loads(auth) if auth else {}
        except Exception:
            auth = {}
    if not isinstance(auth, dict):
        auth = {}
    if event == "ONIMBOTMESSAGEADD":
        result = process_imbot_message(db, data, auth)
        return JSONResponse(result)
    return JSONResponse({"status": "ok", "event": event, "trace_id": tid})


@router.get("/events")
async def bitrix_events_get():
    """Bitrix/checks: GET /v1/bitrix/events -> 200 JSON so Bitrix URL checks don't get 405."""
    return JSONResponse(
        {"status": "ok", "method": "GET", "note": "events endpoint accepts POST"},
        status_code=200,
    )


@router.head("/events")
async def bitrix_events_head():
    """Bitrix/checks: HEAD /v1/bitrix/events -> 200 JSON."""
    return JSONResponse(
        {"status": "ok", "method": "HEAD", "note": "events endpoint accepts POST"},
        status_code=200,
    )


@router.options("/events")
async def bitrix_events_options():
    """Bitrix/checks: OPTIONS /v1/bitrix/events -> 200 OK (CORS)."""
    return PlainTextResponse("", status_code=200)


@router.post("/events")
async def bitrix_events(request: Request, db: Session = Depends(get_db)):
    merged = await parse_bitrix_body(request)
    tid = _trace_id(request)
    event = merged.get("event", "")
    data = merged.get("data", merged)
    auth = merged.get("auth", {})
    if isinstance(auth, str):
        try:
            auth = json.loads(auth) if auth else {}
        except Exception:
            auth = {}
    if not isinstance(auth, dict):
        auth = {}
    if event == "ONIMBOTMESSAGEADD":
        result = process_imbot_message(db, data, auth)
        return JSONResponse(result)
    return JSONResponse({"status": "ok", "event": event, "trace_id": tid})


@router.post("/placement")
async def bitrix_placement(request: Request):
    return JSONResponse({"status": "ok"})
